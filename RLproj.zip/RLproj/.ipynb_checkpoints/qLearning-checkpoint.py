import numpy as np
import tictactoe as ttt

x_controls = np.eye(9, dtype=int)

o_conrols = 2*x_controls

total_controls = np.vstack((x_controls, o_conrols, np.zeros(9, dtype=int)))

estados = np.loadtxt('estados_unicos.txt', dtype=int, delimiter=',')

relaciones = np.loadtxt('relaciones.txt', dtype=int, delimiter=',')

nodos = np.loadtxt('nodos.txt', dtype=int, delimiter=',')

s_s = np.loadtxt('s_s.txt', dtype=int, delimiter=',')


def ind_setat(arr):
	ind = np.where((estados == arr).all(axis=1))
	ind = ind[0]
	return ind[0]

## Dada una posicion da los nodos relacionados
def nodos_pos(pos):
	nds = nodos[pos]
	nds = nds[nds != -1]

	return nds

## en un arreglo elige al azar un elemento
def elige_azar(arreglo):
	elemento = np.random.choice(arreglo)

	return elemento

# dada la posicion de cada estado encuentra el indice de Q
def pos_Q(pos_1, pos_2):
	ind = np.where((s_s == (pos_1, pos_2)).all(axis=1))
	ind = ind[0]
	return ind[0]

# print(pos_Q(4,3610))
def min_in_Q(Q, pos):
	a = s_s[:, 0]
	indices = np.argwhere(a == pos).flatten()

	sub_Q = Q[indices]
	mini = np.argmin(sub_Q)

	i = indices[mini]
	mini = sub_Q[mini]
	return mini, i

def hay_terminales(pos, nds):
	
	hay_terminal = False
	res = None

	arr = np.array([], dtype=int)
	for n in nds:
		if_terminal = ttt.terminal(estados[n])[0]
		if if_terminal:
			hay_terminal = True
			arr = np.append(arr, n)

	if hay_terminal:
		res = np.random.choice(arr)

	return hay_terminal, res


beta = 0.9
## Dado un estado inical evalua Q 
def qLearning(arr):
	Q = np.zeros(len(relaciones))
	n = len(arr[arr == 0])


	cant_epis = 100000

	ind_inicial = ind_setat(arr)
	
	# print(ind_inicial)
	for i in range(cant_epis):
		
		actual = ind_inicial
		if_terminal = ttt.terminal(arr)[0]
		
		alpha_k = 1

		while not if_terminal:
			nds = nodos_pos(actual)
			hay_terminal, ind_terminal = hay_terminales(actual, nds)
			if hay_terminal:
				sig = ind_terminal
			else:
				sig = elige_azar(nds)

			cost = ttt.costos(estados[sig])

			## actualizacion de Q
			ind_Q = pos_Q(actual, sig)
			Q[ind_Q] = Q[ind_Q] + alpha_k*(cost + beta*min_in_Q(Q, sig)[0]- Q[ind_Q])

			alpha_k = alpha_k*(1/2)
			actual = sig
			if_terminal = ttt.terminal(estados[actual])[0]
	
	
	ind_q_min = min_in_Q(Q, ind_inicial)[1]
	print(ind_q_min)
	print(s_s[(ind_q_min):(ind_q_min + 6)])
	print(Q[(ind_q_min):(ind_q_min + 9)])
	return s_s[ind_q_min,1]

arr = np.array([0, 0, 0, 0, 0, 0, 0, 0, 0])
print(estados[qLearning(arr)])
# pos = ind_setat(arr)
# nds = nodos_pos(pos)
# # print(estados[nds])
# hay_ter = hay_terminales(pos, nds)
# print(hay_ter)