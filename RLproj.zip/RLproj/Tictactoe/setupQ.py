import numpy as np
import tictactoe as ttt

x_controls = np.eye(9, dtype=int)

o_conrols = 2*x_controls

total_controls = np.vstack((x_controls, o_conrols, np.zeros(9, dtype=int)))

estados = np.loadtxt('estados_unicos.txt', dtype=int, delimiter=',')

# print(ttt.convert_array_board(estados[613]))
## Dado un estado devulevo el indice
# def ind_setat(arr):
# 	ind = np.where((estados == arr).all(axis=1))
# 	ind = ind[0]
# 	return ind[0]

# rel_m = np.ones((1, 4))

# for i in range(len(estados)):
# 	arr = estados[i]

# 	acc, ind_acc = ttt.acciones_adm(arr)

# 	arr_st = np.tile(arr,(len(acc), 1)) + acc
	
# 	out = np.ones((len(acc),4))

# 	for j in range(len(acc)):
# 		ind_arrive = ind_setat(arr_st[j])
# 		cost = ttt.costos(arr)
# 		out[j, 0], out[j, 1] = i, ind_acc[j]
# 		out[j, 2], out[j, 3] = cost, ind_arrive


# 	rel_m = np.vstack((rel_m, out))

# rel_m = rel_m[1:]
np.savetxt('Q.txt', np.zeros(17125), fmt='%i', delimiter=',')

# rel = np.loadtxt('relaciones_1.txt', delimiter=',')

# A = np.ones((len(rel), 2))

# for i in range(len(rel)):
# 	A[i, 0] = rel[i, 0]
# 	A[i, 1] = rel[i, 3]

# np.savetxt('s_s_1.txt', A, fmt='%i', delimiter=',')

# ## Con un estado inicial le da 
# def q-L(inicial)

# nodos = np.loadtxt('nodos.txt', dtype=int, delimiter=',')

# for i in range(len(nodos)):
# 	n = nodos[i]
# 	n[n == -1] = -2
# 	n = n+1
# 	nodos[i] = n

# o = -1*np.ones((len(nodos), 1))

# nodos = np.hstack((nodos, o))
# np.savetxt('nodos_1.txt', nodos, fmt='%i', delimiter=',')