import numpy as np
import tictactoe as ttt


estados = np.loadtxt('estados_unicos.txt', dtype=int, delimiter=',')

relaciones = np.loadtxt('relaciones.txt', dtype=int, delimiter=',')

s_a_s = relaciones[:,[0,1,3]]

# print(s_a_s)

def find_sts(arr):
	ind = np.where((estados == arr).all(axis=1))
	ind = ind[0]
	return ind[0]


## Da los indices de Q para el indice de un estado
def find_Q(ind):
	S = s_a_s[:, 0]

	ind_s_Q = np.argwhere(S == ind).flatten()

	return ind_s_Q

#dado un estado y una accion devuelve su posicion
def pos_Q(ind_s, ind_a):
	s_a = s_a_s[:, 0:2]

	ind = np.where((s_a == (ind_s, ind_a)).all(axis=1))
	ind = ind[0]
	return ind[0]

## Carga el Q anterior
def loadQ(ind):
	path = 'Q.txt'
	Q = np.loadtxt(path, delimiter=',')

	return Q

def saveQ(Q, ind):
	path = 'Q.txt'
	np.savetxt(path, Q, delimiter=',')


## Dado el indice de un estado decide que accion tomar
def estrategia(Q, ind):
	next_ac, next_st = None, None
	S = s_a_s[:, 0]
	A = s_a_s[:, 1]
	S_1 = s_a_s[:, 2]

	arr = estados[ind]

	turn = ttt.turno(arr)

	ind_s = np.argwhere(S == ind).flatten()
	pos_fin = np.array([])
	
	for i in ind_s:
		ind_s_1 = S_1[i]
		arr = estados[ind_s_1]
		dispo = arr

		is_term = ttt.terminal(dispo)[0]
		if is_term:
			pos_fin = np.append(pos_fin, i)

	if len(pos_fin) > 0:
		i = int(np.random.choice(pos_fin))
		next_ac = A[i]
		next_st = S_1[i]
	else:
		rand = np.random.random_sample()
		if rand < 0.6:
			if turn == 2:
				ind_tom = np.argmin(Q[ind_s])
			else:
				ind_tom = np.argmax(Q[ind_s])
			
			ind_tom = ind_s[ind_tom]
			next_ac = A[ind_tom]
			next_st = S_1[ind_tom]
		else:
			i = int(np.random.choice(ind_s))
			next_ac = A[i]
			next_st = S_1[i]

	return next_ac, next_st


beta = 0.999
def q_learning(arr):
	ind = find_sts(arr)
	Q = loadQ(ind)

	cant_epis = 1000

	for i in range(cant_epis):
		ind_actual = ind

		dispo = arr
		is_term = ttt.terminal(dispo)[0]

		alpha_k = 0.9
		while not is_term:
			next_ac, next_st = estrategia(Q, ind_actual)

			costo = ttt.costos(estados[next_st])
			# print(tmm.convert_array_board(estados[ind_actual,:-1]))
			# print(costo)
			ind_Q_obs = find_Q(next_st)

			if int(ttt.turno(dispo)) == 2:
				min_Q = np.amax(Q[ind_Q_obs])
			else:
				min_Q = np.amin(Q[ind_Q_obs])

			ind_Q_ac = pos_Q(ind_actual, next_ac)
			Q[ind_Q_ac] = Q[ind_Q_ac] + alpha_k*(costo + beta*min_Q - Q[ind_Q_ac])
			# print(Q[ind_Q_ac])
			##
			alpha_k = alpha_k*(0.9)
			ind_actual = next_st
			
			arr_1 = estados[ind_actual]
			dispo = arr_1
			is_term = ttt.terminal(dispo)[0]

	saveQ(Q, ind)

	ind_eval = find_Q(ind)
	print(Q[ind_eval])

	ind_tom = np.argmin(Q[ind_eval])
	ind_tom = ind_eval[ind_tom]
	# print(ind_tom)
	Q_value, ctr_value, s_value = Q[ind_tom], s_a_s[ind_tom, 1], s_a_s[ind_tom, 2]

	return Q_value, ctr_value, s_value


arr = np.array([2,1,2,0,0,1,0,0,0])

Q_value, ctr_value, s_value = q_learning(arr)
# print(Q_value)
print(estados[s_value])

valores = np.loadtxt('valores.txt', delimiter=',')

# for i in range(1000):
# 	Q_value, ctr_value, s_value = q_learning(arr)

# 	valores = np.append(valores, Q_value)

# np.savetxt('valores.txt', valores, delimiter=',')