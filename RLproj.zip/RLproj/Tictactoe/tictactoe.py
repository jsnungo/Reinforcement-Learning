import numpy as np

x_controls = np.eye(9, dtype=int)

o_conrols = 2*x_controls

total_controls = np.vstack((x_controls, o_conrols, np.zeros(9, dtype=int)))
## conveirte arreglo a tablero
def convert_array_board(arr):
	board = np.reshape(arr, (3,3))

	return board

## converte tablero a arreglo
def convert_board_array(board):
	arr = board.flatten()

	return arr

## Determina si un tablero es psoible
def pos_state(arr):
	pos_o = np.argwhere(arr == 2)
	pos_x = np.argwhere(arr == 1)
	pos_empty = np.argwhere(arr == 0)
	
	cant_o = len(pos_o)
	cant_x = len(pos_x)
	cant_empty = len(pos_x)
	
	cond = (cant_x + 1 == cant_o) or cant_x == cant_o
	return cond

## Determina si un estado es terminal
## Tambien devuelve el ganador
def terminal(arr):
	if_teminal, winner = False, None
	
	x_wins = np.ones(3)
	o_wins = 2*x_wins

	board = convert_array_board(arr)

	##verifico las diagonales
	diag_board = board[range(3), range(3)]
	ant_diag_baord = board[[0, 1, 2],[2, 1, 0]]
	## Verifica si la (anti)diagonal tiene todas x
	if (diag_board == x_wins).all() or (ant_diag_baord == x_wins).all():
		if_teminal = True
		winner = 1
	## Verifica si la (anti)diagonal tiene todas o
	if (diag_board == o_wins).all() or (ant_diag_baord == o_wins).all():
		if_teminal = True
		winner = 2

	if not if_teminal:
		## verifica ganadores horizontales o vrticales
		for i in range(3):
			row = board[i, :]
			col = board[:, i]

			if (row == x_wins).all() or (col == x_wins).all():
				if_teminal = True
				winner = 1
				break
			if (row == o_wins).all() or (col == o_wins).all():
				if_teminal = True
				winner = 2
				break

	if not if_teminal:
		pos_empty = np.argwhere(arr == 0).flatten()

		if len(pos_empty) == 0:
			if_teminal = True
			winner = 0

	return if_teminal, winner

# tablero = np.array([ [2, 1, 2],
# 					 [2, 2, 1],
# 					 [1, 2, 1]])
# arr = convert_board_array(tablero)
# print(pos_state(arr))
# print(terminal(arr))
# # inicial = np.zeros(9)

def turno(arr):
	turn = 2
	pos_o = np.argwhere(arr == 2).flatten()
	pos_x = np.argwhere(arr == 1).flatten()

	cant_o = len(pos_o)
	cant_x = len(pos_x)

	if cant_o > cant_x:
		turn = 1

	return turn


##
## Determina las acciones admisibles desde un tablero 	
def acciones_adm(arr):
	adm_controls, ind_cotrol = None, None

	pos_o = np.argwhere(arr == 2).flatten()
	pos_x = np.argwhere(arr == 1).flatten()
	pos_empty = np.argwhere(arr == 0).flatten()
	
	cant_o = len(pos_o)
	cant_x = len(pos_x)
	cant_empty = len(pos_empty)

	## Minimo se necesitan 4 jugadas para tener un estado terminal
	if cant_empty <= 4:
		if_terminal, winner = terminal(arr)
		if if_terminal:
			ind_cotrol = [18]
			adm_controls = np.zeros((1,9), dtype=int)
			return adm_controls, ind_cotrol
	
	if cant_o > cant_x:
		## Turno de x
		ind_cotrol = pos_empty
		adm_controls = x_controls[pos_empty]

	else:
		## turno de o
		ind_cotrol = 9 + pos_empty
		adm_controls = o_conrols[pos_empty]

	return adm_controls, ind_cotrol

# tablero = np.array([ [2, 1, 1],
# 					 [1, 1, 2],
# 					 [2, 2, 0]])

# arr = convert_board_array(tablero)

# admisibles_tablero, indices = acciones_adm(arr)



# conroles_table = total_controls[indices]
# print(conroles_table)

# for acc in admisibles_tablero:
# 	print(convert_array_board(acc))
# for acc in conroles_table:
# 	print(convert_array_board(acc))

## Dado un estado le doy los posibles estados de llegada
def arrive_state(arr):
	adm_controls = acciones_adm(arr)[0]
	states = np.tile(arr,(len(adm_controls), 1)) + adm_controls

	return states

# tablero = np.array([ [2, 0, 1],
# 					 [2, 0, 0],
# 					 [2, 0, 1]])


# arr = convert_board_array(tablero)

# # print(terminal(arr))
# arrive_s = arrive_state(arr)

# for arr in arrive_s:
# 	print(convert_array_board(arr))


def arbol(matriz, inical):
	if_terminal = terminal(inical)[0]
	if not if_terminal:
		arrive_s = arrive_state(inical)
		for arr in arrive_s:
			matriz =  np.vstack((matriz, arr))
			matriz = arbol(matriz, arr)
	
	return matriz


# tablero = np.array([ [2, 0, 0],
# 					 [0, 0, 0],
# 					 [0, 0, 0]])


# arr = convert_board_array(tablero)
# matriz = [arr]

# arbol = arbol(matriz, arr)

# for arr in arbol:
# 	if not pos_state(arr):
# 		print('alerta')
# 		print(arr)


# all_states = np.ones((1, 9))

# for control in o_conrols:
# 	print('Entra control')
# 	matriz = [control]
# 	arboleto = arbol(matriz, control)
# 	print(len(arboleto))
# 	all_states = np.vstack((all_states, arboleto))
# 	print('sale control ')

# np.savetxt('estados.txt', all_states, fmt='%i', delimiter=',')

# estados = np.loadtxt('estados.txt', dtype=int, delimiter=',')

# estados_unicos = np.unique(estados[1:], axis=0)
# print(len(estados_unicos))
# np.savetxt('estados_unicos.txt', estados_unicos, fmt='%i', delimiter=',')

def veri_clases_equivalen(arr_1, arr_2):
	res = False
	board_1 = convert_array_board(arr_1)
	board_2 = convert_array_board(arr_2)
	board_2_T = board_2.T
	
	for i in range(4):
		if (board_1 == board_2).all() or (board_1 == board_2.T).all():
		# if (board_1 == board_2).all():
			res = True
			break

		board_2 = np.rot90(board_2)
		board_2_T = np.rot90(board_2_T)

	return res

# estados = np.loadtxt('estados_unicos.txt', dtype=int, delimiter=',')

# e_1 = convert_array_board(np.array([1, 1, 2, 2, 2, 1, 1, 2, 2]))

# # e_2 = convert_array_board(np.array([1, 2, 1, 1, 2, 2, 2, 1, 2]))

# # print(veri_clases_equivalen(e_1, e_2))
# # print(len(estados))
# count = 0

# gana_x = 0
# gana_o = 0
# empate = 0

# terminales = np.ones((958, 9), dtype=int)
# x_terminales = np.ones((316, 9), dtype=int)
# o_terminales = np.ones((626, 9), dtype=int)
# draw_terminales = np.ones((16, 9), dtype=int)

# ter = np.zeros
# for arr in estados:
# 	condition = terminal(arr)
# 	if condition[0]:
# 		terminales[count] = arr
# 		count +=1
# 		if condition[1] == 1:
# 			x_terminales[gana_x] = arr
# 			gana_x += 1
# 		elif condition[1] == 2:
# 			o_terminales[gana_o] = arr
# 			gana_o += 1
# 		else:
# 			# print(convert_array_board(arr))
# 			draw_terminales[empate] = arr
# 			empate += 1

# print('Termin:::', count)
# print('Gana o:::', gana_o)
# print('Gana x:::', gana_x)
# print('Empate:::', empate)

def dist_clases(matriz):
	rep_clases = np.array([matriz[0]])

	for arr in matriz:
		exist = False
		for rep_c in rep_clases:
			cond = veri_clases_equivalen(rep_c, arr)
			if cond:
				exist = True
				break
		
		if not exist:
			rep_clases = np.vstack((rep_clases, arr))

	return rep_clases

# print(len(dist_clases(terminales)))

def costos(arr):
	costo = 0

	if_teminal, winner = terminal(arr)

	if if_teminal:
		if winner == 1:
			costo = 1
		elif winner == 2:
			costo = -1
	
	return costo	