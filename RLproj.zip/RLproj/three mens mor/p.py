import numpy as np
import matplotlib.pyplot as plt


# np.savetxt('Q.txt', np.zeros(32779), fmt='%i', delimiter=',')

val = np.loadtxt('val.txt', delimiter=',')

x = range(len(val))

plt.plot(x, val)
plt.xlabel('Episodios')
plt.ylabel('V(s)')

plt.show()