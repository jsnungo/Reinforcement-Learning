import numpy as np
import thremmorris as tmm

estados = tmm.states

s_a_s = np.loadtxt('s_a_s.txt', dtype=int, delimiter=',')



## Da los indices de Q para el indice de un estado
def find_Q(ind):
	S = s_a_s[:, 0]

	ind_s_Q = np.argwhere(S == ind).flatten()

	return ind_s_Q

#dado un estado y una accion devuelve su posicion
def pos_Q(ind_s, ind_a):
	s_a = s_a_s[:, 0:2]

	ind = np.where((s_a == (ind_s, ind_a)).all(axis=1))
	ind = ind[0]
	return ind[0]

## Carga el Q anterior
def loadQdos(ind):
	path = 'Qdos.txt'
	Q = np.loadtxt(path, delimiter=',')

	return Q

def saveQdos(Q, ind):
	path = 'Qdos.txt'
	np.savetxt(path, Q, delimiter=',')


## Carga el Q anterior
def loadQuno(ind):
	path = 'Quno.txt'
	Q = np.loadtxt(path, delimiter=',')

	return Q

def saveQuno(Q, ind):
	path = 'Quno.txt'
	np.savetxt(path, Q, delimiter=',')


## Dado el indice de un estado decide que accion tomar
def estrategia(Q, ind, epsilon, turno_int):
	next_ac, next_st = None, None
	S = s_a_s[:, 0]
	A = s_a_s[:, 1]
	S_1 = s_a_s[:, 2]

	turn = estados[ind, -1]

	ind_s = np.argwhere(S == ind).flatten()
	pos_fin = np.array([])
	
	for i in ind_s:
		ind_s_1 = S_1[i]
		arr = estados[ind_s_1]
		dispo = arr[:-1]

		is_term = tmm.is_terminal(dispo)[0]
		if is_term:
			pos_fin = np.append(pos_fin, i)

	if len(pos_fin) > 0:
		i = int(np.random.choice(pos_fin))
		next_ac = A[i]
		next_st = S_1[i]
	else:
		rand = np.random.random_sample()
		if rand < epsilon:
			if turn == int(turno_int):
				ind_tom = np.argmin(Q[ind_s])
			else:
				ind_tom = np.argmax(Q[ind_s])
			
			ind_tom = ind_s[ind_tom]
			next_ac = A[ind_tom]
			next_st = S_1[ind_tom]
		else:
			i = int(np.random.choice(ind_s))
			next_ac = A[i]
			next_st = S_1[i]

	return next_ac, next_st


# val = np.zeros(100000)
beta = 0.999
def q_learning_parados(arr):
	ind = tmm.find_sts(arr)
	Q = loadQdos(ind)

	cant_epis = 500

	for i in range(cant_epis):
		ind_actual = ind

		dispo = arr[:-1]
		is_term = tmm.is_terminal(dispo)[0]

		alpha_k = 0.9
		while not is_term:
			next_ac, next_st = estrategia(Q, ind_actual, 0.7, 2)

			costo = tmm.costdos(estados[next_st])
			# print(tmm.convert_array_board(estados[ind_actual,:-1]))
			# print(costo)
			ind_Q_obs = find_Q(next_st)

			if int(estados[ind_actual,-1]) == 2:
				min_Q = np.amax(Q[ind_Q_obs])
			else:
				min_Q = np.amin(Q[ind_Q_obs])

			ind_Q_ac = pos_Q(ind_actual, next_ac)
			Q[ind_Q_ac] = Q[ind_Q_ac] + alpha_k*(costo + beta*min_Q - Q[ind_Q_ac])
			# print(Q[ind_Q_ac])
			##
			alpha_k = alpha_k*(0.9)
			ind_actual = next_st
			
			arr_1 = estados[ind_actual]
			dispo = arr_1[:-1]
			is_term = tmm.is_terminal(dispo)[0]

		## Solo para la grafica
		# ind_eval = find_Q(ind)
		# # print(Q[ind_eval])

		# ind_tom = np.argmin(Q[ind_eval])
		# ind_tom = ind_eval[ind_tom]
		# # print(ind_tom)
		# Q_value, ctr_value, s_value = Q[ind_tom], s_a_s[ind_tom, 1], s_a_s[ind_tom, 2]
		# val[i] = Q_value
		## Solo para la grafica

	saveQdos(Q, ind)

	ind_eval = find_Q(ind)
	q_values = Q[ind_eval]
	# print(q_values)

	ind_tom = np.argmin(Q[ind_eval])
	ind_tom = ind_eval[ind_tom]
	# print(ind_tom)
	Q_value, ctr_value, s_value = Q[ind_tom], s_a_s[ind_tom, 1], s_a_s[ind_tom, 2]

	return Q_value, ctr_value, s_value, q_values

def q_learning_parauno(arr):
	ind = tmm.find_sts(arr)
	Q = loadQuno(ind)

	cant_epis = 100

	for i in range(cant_epis):
		ind_actual = ind

		dispo = arr[:-1]
		is_term = tmm.is_terminal(dispo)[0]

		alpha_k = 0.9
		while not is_term:
			next_ac, next_st = estrategia(Q, ind_actual, 0.5, 1)

			costo = tmm.costuno(estados[next_st])
			# print(tmm.convert_array_board(estados[ind_actual,:-1]))
			# print(costo)
			ind_Q_obs = find_Q(next_st)

			if int(estados[ind_actual,-1]) == 1:
				min_Q = np.amax(Q[ind_Q_obs])
			else:
				min_Q = np.amin(Q[ind_Q_obs])

			ind_Q_ac = pos_Q(ind_actual, next_ac)
			Q[ind_Q_ac] = Q[ind_Q_ac] + alpha_k*(costo + beta*min_Q - Q[ind_Q_ac])
			# print(Q[ind_Q_ac])
			##
			alpha_k = alpha_k*(0.9)
			ind_actual = next_st
			
			arr_1 = estados[ind_actual]
			dispo = arr_1[:-1]
			is_term = tmm.is_terminal(dispo)[0]


		## Solo para la grafica
		# ind_eval = find_Q(ind)
		# # print(Q[ind_eval])

		# ind_tom = np.argmin(Q[ind_eval])
		# ind_tom = ind_eval[ind_tom]
		# # print(ind_tom)
		# Q_value, ctr_value, s_value = Q[ind_tom], s_a_s[ind_tom, 1], s_a_s[ind_tom, 2]
		# val[i] = Q_value
		## Solo para la grafica

	saveQuno(Q, ind)

	ind_eval = find_Q(ind)
	q_values = Q[ind_eval]
	# print(q_values)

	ind_tom = np.argmin(Q[ind_eval])
	ind_tom = ind_eval[ind_tom]
	# print(ind_tom)
	Q_value, ctr_value, s_value = Q[ind_tom], s_a_s[ind_tom, 1], s_a_s[ind_tom, 2]

	return Q_value, ctr_value, s_value, q_values

# print('cambio')
# arr = np.array([2,0,0,0,0,0,0,0,0,1])

# Q_value, ctr_value, s_value, q_values = q_learning_parauno(arr)
# # # # print(q_values)
# # # # # # print(Q_value)
# print(Q_value)
# print(estados[s_value])
# arr = np.array([0,2,0,0,0,0,0,0,0,1])

# Q_value, ctr_value, s_value, q_values = q_learning_parauno(arr)
# # # # print(q_values)
# # # # # # print(Q_value)
# print(Q_value)
# print(estados[s_value])
# arr = np.array([0,0,2,0,0,0,0,0,0,1])

# Q_value, ctr_value, s_value, q_values = q_learning_parauno(arr)
# # # # print(q_values)
# # # # # # print(Q_value)
# print(Q_value)
# print(estados[s_value])
# arr = np.array([0,0,0,2,0,0,0,0,0,1])

# Q_value, ctr_value, s_value, q_values = q_learning_parauno(arr)
# # # # print(q_values)
# # # # # # print(Q_value)
# print(Q_value)
# print(estados[s_value])
# arr = np.array([0,0,0,0,2,0,0,0,0,1])

# Q_value, ctr_value, s_value, q_values = q_learning_parauno(arr)
# # # # print(q_values)
# # # # # # print(Q_value)
# print(Q_value)
# print(estados[s_value])
# arr = np.array([0,0,0,0,0,2,0,0,0,1])

# Q_value, ctr_value, s_value, q_values = q_learning_parauno(arr)
# # # # print(q_values)
# # # # # # print(Q_value)
# print(Q_value)
# print(estados[s_value])
# arr = np.array([0,0,0,0,0,0,2,0,0,1])

# Q_value, ctr_value, s_value, q_values = q_learning_parauno(arr)
# # # # print(q_values)
# # # # # # print(Q_value)
# print(Q_value)
# print(estados[s_value])

# for i in range(len(val)):
	# Q_value, ctr_value, s_value = q_learning(arr)
	# val[i] = Q_value

# np.savetxt('val.txt', val, delimiter=',')

# Q = loadQ(ind)
# ind_eval = find_Q(ind)
# print(ind_eval)
# print(Q[ind_eval])


# print('inicio')
# while True:
# 	final = len(s_a_s)

# 	for s in range(1, int(len(estados)/2) ):
# 		arr = estados[-s]
# 		q_learning_parauno(arr)

# 	print('denso')


# for s in estados:
# 	q_learning(s)