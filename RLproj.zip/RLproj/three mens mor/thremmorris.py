import numpy as np

## conveirte arreglo a tablero
def convert_array_board(arr):
	board = np.reshape(arr, (3,3))

	return board

## converte tablero a arreglo
def convert_board_array(board):
	arr = board.flatten()

	return arr

def create_controls():
	all_con = np.zeros((1, 9))
	c_1 = None
	c_2 = None

	## acciones de apertura para 1
	initial_c_1 = np.eye(9, dtype=int)

	guia = np.array([0, 0, 0, 0, -1, 0, 0, 0, 0])
	guia = np.tile(guia, (9, 1))

	diag_c_1 = initial_c_1 + guia
	diag_c_1 = np.delete(diag_c_1, 4, 0)

	inv_diag_c_1 = - diag_c_1

	c_1 = np.vstack((initial_c_1, diag_c_1, inv_diag_c_1))

	a_edges_c_1 = np.array([1, -1, 0, 0, 0, 0, 0, 0, 0])
	b_edges_c_1 = np.array([0, 1, -1, 0, 0, 0, 0, 0, 0])
	
	a_guia = a_edges_c_1
	b_guia = b_edges_c_1
	
	a_edges_c_1 = np.vstack((a_edges_c_1, b_edges_c_1))

	for i in range(1,4):
		a_guia = convert_array_board(a_guia)
		a_guia = np.rot90(a_guia, -i)
		a_guia = convert_board_array(a_guia)

		b_guia = convert_array_board(b_guia)
		b_guia = np.rot90(b_guia, -i)
		b_guia = convert_board_array(b_guia)
		
		a_edges_c_1 = np.vstack((a_edges_c_1, a_guia, b_guia))

	inv_a_edges_c_1 = - a_edges_c_1

	c_1 = np.vstack((c_1, a_edges_c_1, inv_a_edges_c_1))

	c_2 = 2*c_1

	all_con = np.vstack((all_con, c_1, c_2))

	return all_con

# create_controls()

## convertir los controles en txt
def txt_con():
	all_con = create_controls()

	np.savetxt('controlsPP.txt', all_con, fmt='%i', delimiter=',')

# txt_con()
## Dada una disposicion dice si es terminal
def is_terminal(arr):

	is_terminal, winner = False, None
	
	wins_1 = np.ones(3)
	wins_2 = 2*wins_1

	board = convert_array_board(arr)

	##verifico las diagonales
	diag_board = board[range(3), range(3)]
	ant_diag_baord = board[[0, 1, 2],[2, 1, 0]]
	## Verifica si la (anti)diagonal tiene todas x
	if (diag_board == wins_1).all() or (ant_diag_baord == wins_1).all():
		is_terminal = True
		winner = 1
	## Verifica si la (anti)diagonal tiene todas o
	elif (diag_board == wins_2).all() or (ant_diag_baord == wins_2).all():
		is_terminal = True
		winner = 2

	elif not is_terminal:
		## verifica ganadores horizontales o vrticales
		for i in range(3):
			row = board[i, :]
			col = board[:, i]

			if (row == wins_1).all() or (col == wins_1).all():
				is_terminal = True
				winner = 1
				break
			if (row == wins_2).all() or (col == wins_2).all():
				is_terminal = True
				winner = 2
				break

	return is_terminal, winner


def is_initial(arr):
	is_initial = False
	val = arr[arr == 0]
	
	if len(val) > 3:
		is_initial = True

	return is_initial



def gen_states():
	base = [0, 1, 2]
	all_states = np.array(np.meshgrid(base, base, base, base, base, base, base, base, base))
	# all_states = np.meshgrid(base)

	combinations = all_states.T.reshape(-1, 9)

	est = np.zeros(9)
	for i in range(len(combinations)):
		arr = combinations[i]
		o_pos = arr[arr == 0]
		pos_1 = arr[arr == 1]
		pos_2 = arr[arr == 2]

		if len(pos_1) == len(pos_2) == len(o_pos):
			est = np.vstack((est, arr))
		elif len(pos_1) <= len(o_pos) and len(pos_2) <= len(o_pos):
			est = np.vstack((est, arr))
	
	est = est[1:]
	# print(len(est))
	turn = np.ones((len(est), 1))
	est_1 = np.hstack((est, turn))
	turn = 2*turn
	est_2 = np.hstack((est, turn))

	est = np.vstack((est_1, est_2))
	for_dele = np.array([], dtype=int)

	for i in range(len(est)):
		arr = est[i]
		turn = int(arr[-1])
		arr = arr[:-1]

		pos_1 = arr[arr == 1]
		pos_2 = arr[arr == 2]

		if turn == 1 and len(pos_1) > len(pos_2):
			for_dele = np.append(for_dele, i)
		elif turn == 2 and len(pos_2) > len(pos_1):
			for_dele = np.append(for_dele, i)
		elif (len(pos_1) > len(pos_2) +1) or (len(pos_2) > len(pos_1) +1):
			for_dele = np.append(for_dele, i)

	est = np.delete(est, for_dele, axis=0)
	np.savetxt('statesPP.txt', est, fmt='%i', delimiter=',')

	## toca eliminar los empates !!!

# gen_states(
controls = np.loadtxt('controls.txt', dtype=int, delimiter=',')

# dado un control encuentra su posicion
def find_control(acc):
	ind = np.where((controls == acc).all(axis=1))
	ind = ind[0]
	return ind[0]

states = np.loadtxt('states.txt', dtype=int, delimiter=',')
# dado un estado encuentra su indice
def find_sts(arr):
	ind = np.where((states == arr).all(axis=1))
	ind = ind[0]

	return ind[0]


M_adyc = np.loadtxt('adyacencias.txt', dtype=int, delimiter=',')
## verifico si dos nodos son adyacentes
def pos_ad(pos_1, pos_2):
	is_adyc = (M_adyc[pos_1, pos_2] == 1)

	return is_adyc

## Dado un estado dice cuales son los estados admisibles
def acc_admisibles(arr):
	ctr, ind_ctr = None, np.array([], dtype=int)

	##  
	turn = int(arr[-1])
	##
	dispo = arr[:-1]


	if is_terminal(dispo)[0]:
		ctr = np.zeros((1, 9), dtype=int)
		ind_ctr = np.zeros(1)

	elif is_initial(dispo):
		o_pos = np.argwhere(dispo != 0).flatten()
		posi = turn*np.eye(9, dtype=int)
		ctr = np.delete(posi, o_pos, axis=0)
		for acc in ctr:
			ind_ctr = np.append(ind_ctr, find_control(acc))
	else:
		### como el juego tiene todas la fichas en juego 
		### o_pos = jug_pos
		o_pos = np.argwhere(dispo == 0).flatten()
		jug_pos = np.argwhere(dispo == turn).flatten()
		
		mesh = np.array(np.meshgrid(o_pos, jug_pos))
		combinations = mesh.T.reshape(-1, 2)

		posi_ad = np.zeros(9)

		for com in combinations:
			pos_1, pos_2 = com[0], com[1]
			if pos_ad(pos_1, pos_2):
				ad = np.zeros(9)
				ad[pos_1], ad[pos_2] = turn, -turn
				posi_ad = np.vstack((posi_ad, ad))
				ind_ctr = np.append(ind_ctr, find_control(ad))
		ctr = posi_ad[1:]
				

	return ctr, ind_ctr


# arr = np.array([2,0,0,1,1,2,0,2,1,2])
# print(acc_admisibles(arr)[1])

# print(is_terminal(arr))

# # dado un estado dice cuales son los siguientes
def next_state(arr):
	turn, dispo = int(arr[-1]), arr[:-1]
	
	next_turn = None
	if turn == 1:
		next_turn = 2
	else:
		next_turn = 1

	adm_controls, ind = acc_admisibles(arr)
	if ind[0] == 0:
		next_states = np.array([arr])
	else:
		next_states = np.tile(dispo,(len(adm_controls), 1)) + adm_controls

		next_turn = next_turn*np.ones((len(adm_controls), 1))

		next_states = np.hstack((next_states, next_turn))

	return next_states

## Computador es 2
## costo de cada estado
def costdos(arr):
	c = 0
	turn, dispo = int(arr[-1]), arr[:-1]
	is_ter, winner = is_terminal(dispo)
	if is_ter:
		if winner == 2:
			c = -1
		elif winner == 1:
			c = 1

	return c


def costuno(arr):
	c = 0
	turn, dispo = int(arr[-1]), arr[:-1]
	is_ter, winner = is_terminal(dispo)
	if is_ter:
		if winner == 2:
			c = 1
		elif winner == 1:
			c = -1

	return c



s_a_s = np.loadtxt('s_a_s.txt', dtype=int, delimiter=',')

def cost_beta(arr):
	c = 0
	turn, dispo = int(arr[-1]), arr[:-1]
	is_ter, winner = is_terminal(dispo)
	if is_ter:
		if winner == 2:
			c = -1
		elif winner == 1:
			c = 1
	elif turn == 2:
		jug = len(acc_admisibles(arr)[1])
		if jug == 1:
			c = 1
	elif turn == 1:

		ter = False

		next_s = next_state(arr)

		for s in next_s:
			cond, w = is_terminal(s[:-1])
			jug = len(acc_admisibles(s)[1])
			if jug == 1:
				ter = True
				break

			if cond and w == 1:
				ter = True
				break

		if ter:
			c = 1

	return c

# states = np.loadtxt('states.txt', dtype=int, delimiter=',')
# arr = np.array([0,,1,1,1,0,2,0,0,2])
# print(cost_beta(arr))
# a = np.where((states == arr).all(axis=1))[0]
# print(find_sts(arr))
# print(a)
# print(next_state(arr))

# s_a_s = np.zeros(3)

# for i in range(len(states)):
# 	# print(i)
# 	arr = states[i]

# 	ctr_arr, ctr_ind = acc_admisibles(arr)
# 	st_arr = next_state(arr)
# 	if i == 47:
# 		print(arr)
# 		print(ctr_arr)
# 		print(st_arr[0])

# 	ad = np.zeros((len(ctr_arr), 3))

# 	for j in range(len(ctr_arr)):
# 		# print(j)
# 		n_s = st_arr[j]
# 		ind_n_s = find_sts(n_s)
# 		ad[j, 0] = i
# 		ad[j, 1] = ctr_ind[j]
# 		ad[j, 2] = ind_n_s

# 	s_a_s = np.vstack((s_a_s, ad))

# s_a_s = s_a_s[1:]


# np.savetxt('Qdos.txt', np.zeros(32779), fmt='%i', delimiter=',')
