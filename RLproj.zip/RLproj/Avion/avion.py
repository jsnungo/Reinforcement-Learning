import numpy as np
import time as tm
from scipy import sparse
##

x, y = np.meshgrid(np.arange(0, 50), np.arange(0, 50))
x = np.reshape(x, len(x)**2)
y = np.reshape(y, len(y)**2)

arregloEstados = np.column_stack((x, y))

# Dado una posicion (i, j), retorna el indices en el arreglo de estados
def indu(i, j):
    if 0 <= i <= 49 and 0 <= j <= 49:
        k = (50 * j) + i
    else:
        k = -1
    return k


# Dado un posicon (i, j) retorna la recompensa del estado
def costo(i, j):
    c = 0
    if 40 <= i <= 45 and 40 <= j <= 45:
        c = -100
    # if 155 <= i <= 157 and 155 <= j <= 157:
    #     c = -100

    # if 85 <= j <= 105 and 15 <= i <= 35:
    #     c = 100
    # elif 15 <= j <= 35 and 50 <= i <= 70:
    #     c = 100
    # elif 120 <= j <= 150 and 90 <= i <= 110:
    #     c = 100
    # elif 75 <= j <= 95 and 130 <= i <= 150:
    #     c = 100
    # elif 10 <= j <= 30 and 160 <= i <= 180:
        # c = 100

    if 5 <= i <= 15 or 35 <= i <= 45:
        if 10 <= j <= 11 or 29 <= j <= 30:
            c = 100
    if 20 <= i <= 30:
        if 19 <= j <= 20 or 36 <= j <= 37 or 42 <= j <= 43:
            c = 100


    if j == 49 or j == 0:
        c = 100
    if i == 0 or i == 49:
        c = 100

    return c

def recompensa(i, j):
    return - costo(i, j)

# Dado un estado (i, j), y una accion a.
# Retorna los estados con posible probabilidad positvia
def indexEstadosInteres(i, j, a):
    indices = []
    if a == 0:
        indices.append(indu(i, j + 1))
        indices.append(indu(i, j + 2))
        indices.append(indu(i - 1, j + 2))
        indices.append(indu(i - 1, j + 1))
    elif a == 1:
        indices.append(indu(i, j))
        indices.append(indu(i, j - 1))
        indices.append(indu(i - 1, j))
        indices.append(indu(i - 1, j - 1))
    elif a == 2:
        indices.append(indu(i - 1, j + 1))
        indices.append(indu(i - 1, j))
        indices.append(indu(i - 2, j))
        indices.append(indu(i - 2, j + 1))
    elif a == 3:
        indices.append(indu(i + 1, j))
        indices.append(indu(i + 1, j + 1))
        indices.append(indu(i, j))
        indices.append(indu(i, j + 1))

    return np.array(indices)


# Dada una posición determina cuales son las acciones admisibles
def accionesAdmisibles(i, j):
    acciones = [0, 1, 2, 3]

    if i == 0:
        acciones.remove(2)
        if j == 0:
            acciones.remove(1)
        if j == 49:
            acciones.remove(0)
    elif i == 49:
        acciones.remove(3)
        if j == 0:
            acciones.remove(1)
        if j == 49:
            acciones.remove(0)
    elif j == 0:
        acciones.remove(1)
    elif j == 49:
        acciones.remove(0)

    return np.array(acciones)

# Probabiliada de transicion al interior de la reticula
def probTransiconReticula(z, w, i, j, a):
    prob = 0
    if a == 0:
        if z == i and w == j + 1:
            prob = 0.3
        elif z == i and w == j + 2:
            prob = 0.4
        elif z == i - 1 and w == j + 2:
            prob = 0.2
        elif z == i - 1 and w == j + 1:
            prob = 0.1
    elif a == 1:
        if (z == i and w == j) or (z == i and w == j - 1):
            prob = 0.3
        elif (z == i - 1 and w == j) or (z == i - 1 and w == j - 1):
            prob = 0.2
    elif a == 2:
        if (z == i - 1 and w == j + 1) or (z == i - 2 and w == j):
            prob = 0.3
        elif (z == i - 1 and w == j) or (z == i - 2 and w == j + 1):
            prob = 0.2
    elif a == 3:
        if z == i + 1 and w == j:
            prob = 0.3
        elif z == i + 1 and w == j + 1:
            prob = 0.4
        elif z == i and w == j:
            prob = 0.2
        elif z == i and w == j + 1:
            prob = 0.1

    return prob

# Probabilidad de transicion en los estados del borde exterior
# de la reticula
def probTrasicionBordeExterior(z, w, i, j, a):
    prob = 0
    if a == 0:
        if i == 0:
            if j == 48:
                if z == i and w == j + 1:
                    prob = 1
            else:
                if z == i and w == j + 1:
                    prob = 0.45
                elif z == i and w == j + 2:
                    prob = 0.55
        elif i == 49:
            if j == 48:
                if z == i and w == j + 1:
                    prob = 0.6
                elif z == i - 1 and w == j + 1:
                    prob = 0.4
            else:
                prob = probTransiconReticula(z, w, i, j, a)
        elif j == 0:
            prob = probTransiconReticula(z, w, i, j, a)

    elif a == 1:
        if i == 0:
            if z == i and w == j:
                prob = 0.5
            elif z == i and w == j - 1:
                prob = 0.5
        else:
            prob = probTransiconReticula(z, w, i, j, a)
    elif a == 2:
        if j == 49:
            if i == 1:
                if z == i - 1 and w == j:
                    prob = 1
            else:
                if z == i - 1 and w == j:
                    prob = 0.45
                elif z == i - 2 and w == j:
                    prob = 0.55
        elif j == 0:
            if i == 1:
                if z == i - 1 and w == j + 1:
                    prob = 0.55
                elif z == i - 1 and w == j:
                    prob = 0.45
            else:
                prob = probTransiconReticula(z, w, i, j, a)
        elif i == 49:
            prob = probTransiconReticula(z, w, i, j, a)
    elif a == 3:
        if j == 0:
            prob = probTransiconReticula(z, w, i, j, a)
        elif j == 49:
            if z == i + 1 and w == j:
                prob = 0.55
            elif z == i and w == j:
                prob = 0.45
        elif i == 0:
            prob = probTransiconReticula(z, w, i, j, a)

    return prob


# Probabilidad de transicion en el borde interior de la reticula
def probTransicionBordeInterior(z, w, i, j, a):
    prob = 0
    if recompensa(i, j) != 0:
        if z == i and w == j:
            prob =1
    else:
        if a == 0:
            if j == 48:
                if z == i and w == j + 1:
                    prob = 0.6
                elif z == i - 1 and w == j + 1:
                    prob = 0.4
            else:
                prob = probTransiconReticula(z, w, i, j, a)
        elif a == 2:
            if i == 1:
                if z == i - 1 and w == j + 1:
                    prob = 0.55
                elif z == i - 1 and w == j:
                    prob = 0.45
            else:
                prob = probTransiconReticula(z, w, i, j, a)
        else:
            prob = probTransiconReticula(z, w, i, j, a)

    return prob

# Porbabilidad de transicion en toda la reticula.
def probTransicion(z, w, i, j, a):
    if i == 0 or i == 49 or j == 0 or j == 49:
        prob = probTrasicionBordeExterior(z, w, i, j, a)
    elif i == 1 or i == 48 or j == 1 or j == 48:
        prob = probTransicionBordeInterior(z, w, i, j, a)
    else:
        prob = probTransiconReticula(z, w, i, j, a)

    return prob

# Dado un estado y una accion dice cuales son los posibles estados para llegar
#
# def next_st(i, j, a):

## dada un estado y una accion dice los estadoos de llegada
def parallegar(i, j, a):
    est, pr_est = np.array([]), np.array([])

    pos = indexEstadosInteres(i, j, a)
    pos = pos[pos != -1]
    for s in pos:
        w, z = arregloEstados[s, 0], arregloEstados[s, 1]
        pr = probTransicion(w, z, i, j, a)
        if pr != 0:
            est = np.append(est, s)
            pr_est = np.append(pr_est, pr)

    return est, pr_est

# def parallegar(i, j):
#     arreglo = []
#     for h in range(0, 3):
#         arreglo.append(indu(i - 2, j + h))
#         arreglo.append(indu(i - 1, j + h))
#         arreglo.append(indu(i + 2, j + h))
#         arreglo.append(indu(i + 1, j + h))
#         arreglo.append(indu(i, j + h))
#         if h != 0:
#             arreglo.append(indu(i - 2, j - h))
#             arreglo.append(indu(i - 1, j - h))
#             arreglo.append(indu(i + 2, j - h))
#             arreglo.append(indu(i + 1, j - h))
#             arreglo.append(indu(i, j + h))

#     return arreglo

# np.savetxt('Q.txt', np.zeros(9800), delimiter=',')

# s_a = np.zeros(2)
# for s in range(len(arregloEstados)):
#     i, j = arregloEstados[s, 0], arregloEstados[s, 1]

#     acc = accionesAdmisibles(i, j)
#     add = np.zeros(2)
#     for a in acc:
#         add[0] = s
#         add[1] = a
#         s_a = np.vstack((s_a, add))

# s_a = s_a[1:]
# np.savetxt('s_a11.txt', s_a, fmt='%i', delimiter=',')

# for s in arregloEstados:
#     i, j = s[0], s[1]

#     acc = accionesAdmisibles(i, j)

#     for a in acc:
#         pr = parallegar(i, j, a)[1]
#         print(pr, np.sum(pr))
#         if np.sum(pr)!= 1:
#             print(s, a)


# Dada una politica, crea su matriz de probTransicion multiplicada por la
# tase de descuento lambda
def transitionMatrix(mu, lam):
    I = []
    J = []
    V = []
    # start = tm.time()
    for s in range(len(arregloEstados)):
    # for s in range(5):
        i, j = arregloEstados[s, 0], arregloEstados[s, 1]
        a = mu[s]
        estados_interes = indexEstadosInteres(i, j, a)
        for h in estados_interes:
            if h != -1:
                z, w = arregloEstados[h, 0], arregloEstados[h, 1]
                val = lam*probTransicion(z, w, i, j, a)
                if val != 0:
                    I.append(s)
                    J.append(h)
                    V.append(val)
                    # print('(', s,',', h,')', val)
    # end = tm.time()
    # print(end-start)
    valI = np.array(I)
    valJ = np.array(J)
    valV = np.array(V)
    matrix = sparse.coo_matrix((valV, (valI, valJ)),
                    shape=(len(arregloEstados), len(arregloEstados))).tocsr()
    return matrix

# print(recompensa(1, 1))

# print(costo(1,1))