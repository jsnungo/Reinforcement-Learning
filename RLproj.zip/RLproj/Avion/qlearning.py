import numpy as np
import avion as av

# N = 50
N = 50

## Cota iniciando desde cero
B = N -1

x, y = np.meshgrid(np.arange(0, N), np.arange(0, N))

x = np.reshape(x, len(x)**2)
y = np.reshape(y, len(y)**2)

arregloEstados = np.column_stack((x, y))

s_a = np.loadtxt('s_a11.txt', dtype=int, delimiter=',')

## Da los indices de Q para el indice de un estado
def find_Q(ind):
	S = s_a[:, 0]

	ind_s_Q = np.argwhere(S == ind).flatten()

	return ind_s_Q

#dado un estado y una accion devuelve su posicion
def pos_Q(ind_s, ind_a):

	ind = np.where((s_a == (ind_s, ind_a)).all(axis=1))
	ind = ind[0]
	return ind[0]

# print(find_Q(31688))

## Carga el Q anterior
def loadQ():
	path = 'Q.txt'
	Q = np.loadtxt(path, delimiter=',')

	return Q

def saveQ(Q):
	path = 'Q.txt'
	np.savetxt(path, Q, delimiter=',')



def estrategia(Q, ind):
	next_ac = None
	ind_s = find_Q(ind)
	rand = np.random.random_sample()
	if rand < 0.6:
		ind_tom = np.argmin(Q[ind_s])
		ind_tom = ind_s[ind_tom]
	else:
		ind_tom = np.random.choice(ind_s)
		
	next_ac = s_a[ind_tom, 1]

	return next_ac



## dado el indice de un estado y una accion retorna el costo y la accion
def cost_estado(ind_s, ind_a):
	i, j = arregloEstados[ind_s, 0], arregloEstados[ind_s, 1]
	est, prob = av.parallegar(i, j, ind_a)
	# print(est)
	# print(i, j)
	# print(prob)
	s_1 = int(np.random.choice(est, p=prob))

	i, j = arregloEstados[s_1, 0], arregloEstados[s_1, 1]
	cost = av.costo(i, j)

	return cost, s_1

val = np.zeros(100000)
# i, j = 14, 86
# a = 3
# ind_s = av.indu(i, j)
# print(cost_estado(ind_s, a))
beta = 0.999
def qlearning(ind):
	Q = loadQ()
	# Q = np.zeros(len(Q))
	cant_epis = 100000

	for i in range(cant_epis):
		ind_actual = ind
		alpha_k = 0.9
		while True:
			next_ac = estrategia(Q, ind_actual)

			costo, next_st = cost_estado(ind_actual, next_ac)

			ind_Q_obs = find_Q(next_st)
			min_Q = np.amin(Q[ind_Q_obs])

			ind_Q_ac = pos_Q(ind_actual, next_ac)

			Q[ind_Q_ac] = Q[ind_Q_ac] + alpha_k*(costo + beta*min_Q - Q[ind_Q_ac])

			alpha_k = alpha_k*(0.9)
			ind_actual = next_st
			
			if costo != 0:
				break
		## Solo para la grafica
		ind_eval = find_Q(ind)
		# print(Q[ind_eval])
		# print(ind_eval)
		ind_tom = np.amin(Q[ind_eval])
		val[i] = ind_tom
		## Solo para la grafica
	saveQ(Q)
	ind_eval = find_Q(ind)
	print(Q[ind_eval])
	ind_tom = np.argmin(Q[ind_eval])
	ind_tom = ind_eval[ind_tom]

	a = s_a[ind_tom, 1]

	return a

i, j = 15, 15
ind = av.indu(i,j)
print(ind)
ctr_value = qlearning(ind)
# print(Q_value)
# print(Q_value)
# print(estados[s_value])
np.savetxt('val.txt', val, delimiter=',')
cant = len(arregloEstados)

# print(qlearning(ind))
# j = 0
# for i in range(len(arregloEstados)):
# 	# i, j = arregloEstados[-i, 0], arregloEstados[-i, 1]
# 	j = cant - (i+1)

# 	x, y = arregloEstados[j, 0], arregloEstados[j, 1]
# 	# if x <= 25 and y <= 25:
# 	# 	print(x, y, j)
# 	# 	qlearning(j)
# 	print(x, y, j)	
# 	qlearning(j)
