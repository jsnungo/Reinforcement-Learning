import sys
import mosek
import avion as fn
import numpy as np

# Para uso simbolico
inf = 0.0

estados = fn.arregloEstados
recompensa = np.zeros(9800)
k = 0
for s in range(0, len(estados)):
    i, j = estados[s, 0], estados[s, 1]
    acciones = fn.accionesAdmisibles(i, j)
    for a in acciones:
        recompensa[k] = fn.recompensa(i, j)
        k += 1


unos = np.ones(2500)
dist_inicial = unos/2500

path_I = 'I.txt'
path_J = 'J.txt'
path_V = 'V.txt'

I = np.loadtxt(path_I, delimiter=',')
J = np.loadtxt(path_J, delimiter=',')
V = np.loadtxt(path_V, delimiter=',')

# Flujo de impresion en linea
def streamprinter(text):
    sys.stdout.write(text)
    sys.stdout.flush()

n = 2500
m = 9800

def main():
    # Ambiente de Mosek
    with mosek.Env() as env:
        # Crea el objeto task
        with env.Task(0, 0) as task:
            # Hace la conexion en vivo con las respuestas del API
            task.set_Stream(mosek.streamtype.log, streamprinter)

            # tipo de cota para las restricciones
            bkc = mosek.boundkey.fx

            # valor de la cota
            b = dist_inicial

            # tipo de cota para las variables
            bkx = mosek.boundkey.lo

            # cota para las variables
            blx = 0

            # coeficientes del objetivo
            c = recompensa

            # Matriz sparse que representa las restricciones
            subi = I
            subj = J
            valij = V

            numvar = m
            numcon = n

            # Agrega el numero de restricciones, en principio
            # vacias. Y no tiene cotas.
            task.appendcons(numcon)

            # Agraga el numero  de variables. En principio se
            # incian en 0
            task.appendvars(numvar)

            # Determina el vector constante en la funcion objetivo
            for j in range(numvar):
                # Asigna un valor a cada entrada del vector constante
                # en la funcion objetivo
                task.putcj(j, c[j])

                # Asigna la cota para cada entrada del vector variable
                # Note que el cuarto argumento no importa, dado el tipo de cota
                task.putvarbound(j, bkx, blx, blx)

            # Crea la matriz de restricciones.
            task.putaijlist(subi.astype(int),           # Indices en filas i
                            subj.astype(int),           # Indices en columnas j
                            valij)          # Valor en la posicion a_ij

            # Asigna las cotas de las restricciones
            # blc[i] <= constraint_i <= buc[i]
            for i in range(numcon):
                task.putconbound(i, bkc, b[i], b[i])

            # Cual es el objetivo
            task.putobjsense(mosek.objsense.maximize)

            # Soluciona el problema
            task.optimize()
            task.analyzeproblem(mosek.streamtype.log)

            # Obtiene el estado de la solucion
            solsta = task.getsolsta(mosek.soltype.bas)

            if ( solsta == mosek.solsta.optimal or
                    solsta == mosek.solsta.near_optimal):
                y = [0.]*(numcon)

                task.gety(mosek.soltype.bas, y)

                solution = np.array(y)
                np.savetxt('sol.txt', solution, delimiter=',')

                xx = [0.]*numvar

                task.getxx(mosek.soltype.bas, xx)

                solution_2 = np.array(xx)

                np.savetxt('sol_2.txt', solution_2, delimiter=',')

            elif (solsta == mosek.solsta.dual_infeas_cer or
                  solsta == mosek.solsta.prim_infeas_cer or
                  solsta == mosek.solsta.near_dual_infeas_cer or
                  solsta == mosek.solsta.near_prim_infeas_cer):
                print("Primal or dual infeasibility certificate found.\n")
            elif solsta == mosek.solsta.unknown:
                print("Unknown solution status")
            else:
                print("Other solution status")

# call the main function
try:
    main()
except mosek.Error as e:
    print("ERROR: %s" % str(e.errno))
    if e.msg is not None:
        print("\t%s" % e.msg)
        sys.exit(1)
except:
    import traceback
    traceback.print_exc()
    sys.exit(1)
