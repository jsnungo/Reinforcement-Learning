import numpy as np
from scipy import sparse
import avion as fn

estados = fn.arregloEstados

pares_posibles = np.zeros((98000, 3))
guia_index = np.zeros(len(estados))

k = 0
for s in range(0, len(estados)):
    i, j = estados[s, 0], estados[s, 1]
    acciones_admisibles = fn.accionesAdmisibles(i, j)
    for a in acciones_admisibles:
        pares_posibles[k] = [i, j, a]
        k += 1
    guia_index[s] = len(acciones_admisibles)


lam = 0.999

I = []
J = []
V = []
# Crea la matriz de restricciones en formato sparse
cont = 0
for n in range(len(estados)):
    i, j = estados[n, 0], estados[n, 1]
    admisibles = fn.accionesAdmisibles(i, j)
    posibles_origenes = fn.parallegar(i, j)
    for h in posibles_origenes:
        if h != -1:
            pos_inicial = np.sum(guia_index[0:h])
            if n == h:
                for k in range(len(admisibles)):
                    indice_columna = pos_inicial + k
                    a = admisibles[k]
                    val = 1 - lam*fn.probTransicion(i, j, i, j, a)
                    I.append(n)
                    J.append(indice_columna)
                    V.append(val)

            else:
                z, w = estados[h, 0], estados[h, 1]
                admisibles_temp = fn.accionesAdmisibles(z, w)
                for k in range(len(admisibles_temp)):
                    indice_columna = pos_inicial + k
                    a = admisibles_temp[k]
                    val = - lam*fn.probTransicion(i, j, z, w, a)
                    if val != 0:
                        I.append(n)
                        J.append(indice_columna)
                        V.append(val)

val_I = np.array(I)
val_J = np.array(J)
val_V = np.array(V)

np.savetxt('I.txt', val_I, delimiter=',')
np.savetxt('J.txt', val_J, delimiter=',')
np.savetxt('V.txt', val_V, delimiter=',')
