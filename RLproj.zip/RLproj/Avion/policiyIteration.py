import numpy as np
from scipy.sparse import identity, linalg
import avion as fn
import time as tm

# Estados de la reticula indexados
estados = fn.arregloEstados
# Matriz identidad de manera sparse
I = identity(len(estados)).tocsr()

# lam: Tasa de descuento
lam = 0.999

def creacionMu(v_n, mu_n):
    mu_n1 = np.zeros(len(estados))
    for s in range(len(estados)):
        i, j = estados[s, 0], estados[s, 1]
        # Saca las acciones admisibles del estados (i, j)
        acciones_admisibles = fn.accionesAdmisibles(i, j)
        # Vector que gurada el valor asociado a la accion 
        maxi = np.zeros(len(acciones_admisibles))
        for k in range(len(acciones_admisibles)):
            a = acciones_admisibles[k]
            # Posibles estados a los que puedo llegar desde el estado
            # (i, j) tamando la accion a
            estados_interes = fn.indexEstadosInteres(i, j, a)
            # resp: valor asiciado a la accion a
            resp = fn.recompensa(i, j)
            for h in estados_interes:
                z, w = estados[h, 0], estados[h, 1]
                resp += lam*fn.probTransicion(z, w, i, j, a)*v_n[h]
            maxi[k] = resp
        
        mu_n1[s] = acciones_admisibles[np.argmax(maxi)]

    return mu_n1

## Inicio: Policy iteration
mu_n = np.zeros(len(estados))
mu_n1 = np.ones(len(estados))
aux = np.zeros(len(estados))
# recom: Vector que indica la recompensa en cada uno de los estados
recom = np.array([fn.recompensa(estados[s, 0], estados[s, 1]) for s in range(len(estados))])
n = 0
while np.array_equal(mu_n, mu_n1) == False:
    mu_n = mu_n1
    # POLICY EVALUATION
    # P_mu: matriz de transicion dada la politica mu multiplicada
    # por el factor de descuento 
    P_mu = fn.transitionMatrix(mu_n, lam)
    A = I - P_mu
    
    #v_n: Funcion de valor en el tiempo n de la politica mu
    v_n = linalg.spsolve(A, recom)

    aux = v_n


    # POLICY IMPROVEMENT
    mu_n1 = creacionMu(v_n, mu_n)
    if n == 100000:
        break
    
    n += 1

    print(n)



np.savetxt('v_n.txt', v_n, delimiter=',')
m = np.reshape(mu_n1, (50, 50))
np.savetxt('policy.txt', m, delimiter=",")
