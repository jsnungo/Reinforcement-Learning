import numpy as np
import matplotlib.pyplot as plt
import avion as av

e = av.arregloEstados
print(e[1698])
v = np.loadtxt('val.txt', delimiter=',')
v_n = np.loadtxt('sol.txt', delimiter=',')
v_n = - v_n

ind = av.indu(3, 3)
v_real = v_n[ind]
print(ind)
print(v_real)
# v = v - v_real


plt.xlabel('Episodios')
plt.ylabel('V(s), s=(15,15)')


plt.plot(range(len(v)), v)
plt.show()