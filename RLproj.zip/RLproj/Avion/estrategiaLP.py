## creacion de la estrategia segun la programacion lineal
import numpy as np
import avion as fn

estados = fn.arregloEstados
mu = np.loadtxt('sol_2.txt')

pares_posibles = np.zeros((9800, 3))
guia_index = np.zeros(len(estados))

k = 0
for s in range(0, len(estados)):
    i, j = estados[s, 0], estados[s, 1]
    acciones_admisibles = fn.accionesAdmisibles(i, j)
    for a in acciones_admisibles:
        pares_posibles[k] = [i, j, a]
        k += 1
    guia_index[s] = len(acciones_admisibles)


pi_mu = np.zeros(9800)

# for k in range(len(pi_mu)):
for k in range(len(pi_mu)):
    var = mu[k]
    i, j = pares_posibles[k, 0], pares_posibles[k, 1]
    ind_inicio = int(np.sum(guia_index[0:int(fn.indu(i, j))]))
    ind_final = int(ind_inicio + len(fn.accionesAdmisibles(i,j)))
    # print(pares_posibles[ind_inicio:ind_final])
    suma = np.sum(mu[ind_inicio:ind_final])
    if suma != 0:
        pi_mu[k] = var/suma

# np.savetxt('pi_mu.txt', pi_mu ,delimiter=',')
estrategia = np.ones(2500)
indices = np.where(pi_mu == 1)[0]

for k in range(len(indices)):
    n = indices[k]
    a = pares_posibles[n, 2]
    estrategia[k] = a

m = np.reshape(estrategia, (50, 50))
np.savetxt('estraLP.txt', m ,delimiter=',')
