import numpy as np
# from matplotlib.pyplot import cm
import matplotlib.pyplot as plt
import avion as av

# np.savetxt('Q.txt', np.zeros())
ac = av.accionesAdmisibles(0, 0)

# N = 50
N = 50

## Cota iniciando desde cero
B = N -1

x, y = np.meshgrid(np.arange(0, N), np.arange(0, N))

x = np.reshape(x, len(x)**2)
y = np.reshape(y, len(y)**2)

arregloEstados = np.column_stack((x, y))


heatmap = np.zeros((N, N), dtype=int)

s_a = np.loadtxt('s_a11.txt', dtype=int, delimiter=',')
Q = np.loadtxt('Q.txt', delimiter=',')

policy = np.loadtxt('estraLP.txt', dtype=int, delimiter=',')
v_n = np.loadtxt('v_n.txt', delimiter=',')
v_n = -v_n
# c = np.loadtxt('c.txt', delimiter=',')
# Q[4900:] =  c
# print(Q[9799])
# # np.savetxt('Q.txt', Q, delimiter=',')
## Da los indices de Q para el indice de un estado

def find_Q(ind):
	S = s_a[:, 0]

	ind_s_Q = np.argwhere(S == ind).flatten()

	return ind_s_Q

for i in range(len(arregloEstados)):
	ind_eval = find_Q(i)
	# print(Q[ind_eval])
	ind_tom = np.argmin(Q[ind_eval])
	ind_tom = ind_eval[ind_tom]

	a = s_a[ind_tom, 1]
	# print(a)
	x, y = arregloEstados[i, 0], arregloEstados[i, 1]

	heatmap[x, y] = a

# v_nQ = np.zeros(2500)
# for i in range(len(arregloEstados)):
# 	ind_eval = find_Q(i)
# 	# print(Q[ind_eval])
# 	ind_tom = np.amin(Q[ind_eval])
# 	v_nQ[i] = ind_tom

# print(np.linalg.norm(v_n - v_nQ))

# print(heatmap)
# for coo in arregloEstados:
# 	x, y = coo[0], coo[1]
# 	c = av.costo(x, y)

# 	heatmap[x, y] = c

# 	s+=1
# Colores de las acciones
# heatmap = np.zeros((1, 4))
# heatmap[0, 1] = 1
# heatmap[0, 2] = 2
# heatmap[0, 3] = 3
# plt.imshow(heatmap.T, origin='lower', cmap= plt.cm.binary)
# heatmap = policy
plt.imshow(heatmap.T, origin='lower')
plt.show()