import numpy as np
import matplotlib.pyplot as plt 

# N = 50
N = 50

## Cota iniciando desde cero
B = N -1

x, y = np.meshgrid(np.arange(0, N), np.arange(0, N))

x = np.reshape(x, len(x)**2)
y = np.reshape(y, len(y)**2)

arregloEstados = np.column_stack((x, y))


s_a = np.loadtxt('s_a11.txt', dtype=int, delimiter=',')

Q_1 = np.loadtxt('Q 1000ep.txt', delimiter=',')
Q_2 = np.loadtxt('Q 1500ep.txt', delimiter=',')
Q_3 = np.loadtxt('Q 2000ep.txt', delimiter=',')
Q_4 = np.loadtxt('Q 2500ep.txt', delimiter=',')

v_n = np.loadtxt('sol.txt', delimiter=',')
v_n = -v_n
def find_Q(ind):
	S = s_a[:, 0]

	ind_s_Q = np.argwhere(S == ind).flatten()

	return ind_s_Q


v_nQ_1 = np.zeros(2500)
for i in range(len(arregloEstados)):
	ind_eval = find_Q(i)
	# print(Q[ind_eval])
	ind_tom = np.amin(Q_1[ind_eval])
	v_nQ_1[i] = ind_tom

a = np.linalg.norm(v_nQ_1)

v_nQ_2 = np.zeros(2500)
for i in range(len(arregloEstados)):
	ind_eval = find_Q(i)
	# print(Q[ind_eval])
	ind_tom = np.amin(Q_2[ind_eval])
	v_nQ_2[i] = ind_tom
b= np.linalg.norm(v_nQ_2)


v_nQ_3 = np.zeros(2500)
for i in range(len(arregloEstados)):
	ind_eval = find_Q(i)
	# print(Q[ind_eval])
	ind_tom = np.amin(Q_3[ind_eval])
	v_nQ_3[i] = ind_tom
c = np.linalg.norm(v_nQ_3)


v_nQ_4 = np.zeros(2500)
for i in range(len(arregloEstados)):
	ind_eval = find_Q(i)
	# print(Q[ind_eval])
	ind_tom = np.amin(Q_4[ind_eval])
	v_nQ_4[i] = ind_tom

d = np.linalg.norm(v_nQ_4)

# plt.plot(np.array([1000, 1500, 2000, 2500]), [a, b, c, d])
# plt.xlabel('Episodios')
# plt.ylabel(r'$V_{\ast}^Q - V_{\ast}^{DP}$')
# plt.show()

fig, ax = plt.subplots(figsize=(5, 3))
fig.subplots_adjust(bottom=0.2, left=0.2)
ax.plot(np.array([1000, 1500, 2000, 2500]), [a, b, c, d])
ax.set_xlabel('Episodios')
ax.set_ylabel(r'$V_{\ast}^Q - V_{\ast}^{DP}$')
plt.show()